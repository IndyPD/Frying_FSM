Getting the Version of semver
=============================

To know the version of semver itself, use the following construct::

   >>> semver.__version__
   '3.0.2'
