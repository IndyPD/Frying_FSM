Getting the Implemented semver.org Version
==========================================

The semver.org page is the authoritative specification of how semantic
versioning is defined.
To know which version of semver.org is implemented in the semver library,
use the following constant::

   >>> semver.SEMVER_SPEC_VERSION
   '2.0.0'
