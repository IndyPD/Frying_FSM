Migrating to semver3
====================


.. toctree::
    :maxdepth: 1

    migratetosemver3
    replace-deprecated-functions.rst
