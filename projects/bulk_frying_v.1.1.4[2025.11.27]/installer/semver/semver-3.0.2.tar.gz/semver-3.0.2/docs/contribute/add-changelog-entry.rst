.. _add-changelog:

Adding a Changelog Entry
========================

.. include:: ../../changelog.d/README.rst
    :start-after: -text-begin-