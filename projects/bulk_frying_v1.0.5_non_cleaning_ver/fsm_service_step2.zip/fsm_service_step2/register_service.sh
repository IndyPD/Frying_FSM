#!/bin/bash

ServiceName=frying_fsm
PROJECT_ROOT="$(dirname "$(pwd)")"

# Create or update a sudoers file for the user
sudo touch /etc/sudoers.d/user

# Modify the script with the correct project path and copy it
sed "s|# cd /home/user/release/FryingFSM/|# cd /home/user/release/FryingFSM/\ncd $PROJECT_ROOT|" "${ServiceName}_script" > "/tmp/${ServiceName}_script_modified"
sudo cp "/tmp/${ServiceName}_script_modified" "/etc/${ServiceName}_script"
rm "/tmp/${ServiceName}_script_modified"

# Set executable permissions for the project scripts
sudo chmod +x "$PROJECT_ROOT/killTasks.sh"
sudo chmod +x "$PROJECT_ROOT/run.sh"
sudo chmod +x "$PROJECT_ROOT/update_ips.sh"

# Copy the service executable to the /etc/init.d/ directory
sudo cp "$ServiceName" /etc/init.d/

# Set executable permissions for the service script in /etc/init.d/
sudo chmod 775 /etc/init.d/"$ServiceName"

# Set executable permissions for the service script in /etc/
sudo chmod 775 /etc/"${ServiceName}_script"

sudo update-rc.d -f $ServiceName remove
sudo update-rc.d $ServiceName defaults
sudo service $ServiceName restart




