from .configs.version import CURRENT_VERSION

__version__ = CURRENT_VERSION
